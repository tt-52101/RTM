(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[113],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      categoryTitle: 'Category Name',
      categorySubtitle: 'petiole antimasquer nonenduring hoofish unbed anergic sweetwood ailsyte.',
      sections: [{
        'id': 0,
        'title': 'Buying',
        'questions': [{
          'id': 0,
          'question': 'Cake icing gummi bears?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 1,
          'question': 'Jelly soufflé apple pie?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 2,
          'question': 'Soufflé apple pie ice cream cotton?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 3,
          'question': 'Powder wafer brownie?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 4,
          'question': 'Toffee donut dragée cotton candy?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 5,
          'question': 'Soufflé chupa chups chocolate bar?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }]
      }, {
        'id': 1,
        'title': 'Item Support',
        'questions': [{
          'id': 0,
          'question': 'Dessert halvah carrot cake sweet?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 1,
          'question': 'Jelly beans bonbon marshmallow?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 2,
          'question': 'Marzipan chocolate gummi bears bonbon powder?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 3,
          'question': 'Chupa chups lemon drops caramels?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }]
      }, {
        'id': 2,
        'title': 'Payments',
        'questions': [{
          'id': 0,
          'question': 'Oat cake lemon drops sweet sweet?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 1,
          'question': 'Cotton candy brownie ice cream wafer roll?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 2,
          'question': 'Chocolate bonbon cake sugar plum?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 3,
          'question': 'Cake fruitcake chupa chups?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 4,
          'question': 'Fruitcake bonbon dessert gingerbread powder?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }]
      }, {
        'id': 3,
        'title': 'Downloads',
        'questions': [{
          'id': 0,
          'question': 'Marshmallow jelly beans oat cake?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 1,
          'question': 'Cake ice cream jujubes cookie?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 2,
          'question': 'Sesame snaps tart cake pie chocolate?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 3,
          'question': 'Chocolate cake chocolate tootsi?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 4,
          'question': 'Caramels lemon drops tiramisu cake?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 5,
          'question': 'Brownie dessert gummies. Tiramisu bear claw apple?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }]
      }, {
        'id': 4,
        'title': 'Licenses',
        'questions': [{
          'id': 0,
          'question': 'Macaroon tootsie roll?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 1,
          'question': 'Cheesecake sweet soufflé jelly tiramisu chocolate?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 2,
          'question': 'Carrot cake topping tiramisu oat?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 3,
          'question': 'Ice cream soufflé marshmallow?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 4,
          'question': 'Dragée liquorice dragée jelly beans?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 5,
          'question': 'Lemon drops gingerbread chupa chups tiramisu?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }]
      }, {
        'id': 5,
        'title': 'Documents',
        'questions': [{
          'id': 0,
          'question': 'Brownie dessert gummies?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 1,
          'question': 'Cookie tiramisu lollipop?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 2,
          'question': 'Bonbon sugar plum jelly-o?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }, {
          'id': 3,
          'question': 'Halvah chupa chups chupa chups?',
          'answerUrl': '/pages/knowledge-base/category/question'
        }]
      }]
    };
  },
  computed: {},
  methods: {},
  components: {},
  mounted: function mounted() {
    this.$emit('changeRouteTitle', 'Category');
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=template&id=94b5cb70&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=template&id=94b5cb70& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { attrs: { id: "knowledge-base-category-page" } }, [
    _c("p", { staticClass: "mb-4" }, [_vm._v(_vm._s(_vm.categorySubtitle))]),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "vx-row mt-8 match-height" },
      _vm._l(_vm.sections, function(section) {
        return _c(
          "div",
          {
            key: section.id,
            staticClass: "vx-col w-full sm:w-1/2 md:w-1/3 mb-base"
          },
          [
            _c("vx-card", [
              _c("h4", { staticClass: "mb-4" }, [
                _vm._v(_vm._s(section.title))
              ]),
              _vm._v(" "),
              _c(
                "ul",
                { staticClass: "bordered-items" },
                _vm._l(section.questions, function(que) {
                  return _c(
                    "li",
                    { key: que.question, staticClass: "py-2" },
                    [
                      _c("router-link", { attrs: { to: que.answerUrl } }, [
                        _vm._v(_vm._s(que.question))
                      ])
                    ],
                    1
                  )
                }),
                0
              )
            ])
          ],
          1
        )
      }),
      0
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/pages/KnowledgeBaseCategory.vue":
/*!****************************************************************!*\
  !*** ./resources/js/src/views/pages/KnowledgeBaseCategory.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _KnowledgeBaseCategory_vue_vue_type_template_id_94b5cb70___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./KnowledgeBaseCategory.vue?vue&type=template&id=94b5cb70& */ "./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=template&id=94b5cb70&");
/* harmony import */ var _KnowledgeBaseCategory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./KnowledgeBaseCategory.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _KnowledgeBaseCategory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _KnowledgeBaseCategory_vue_vue_type_template_id_94b5cb70___WEBPACK_IMPORTED_MODULE_0__["render"],
  _KnowledgeBaseCategory_vue_vue_type_template_id_94b5cb70___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/KnowledgeBaseCategory.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KnowledgeBaseCategory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./KnowledgeBaseCategory.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KnowledgeBaseCategory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=template&id=94b5cb70&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=template&id=94b5cb70& ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KnowledgeBaseCategory_vue_vue_type_template_id_94b5cb70___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./KnowledgeBaseCategory.vue?vue&type=template&id=94b5cb70& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/KnowledgeBaseCategory.vue?vue&type=template&id=94b5cb70&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KnowledgeBaseCategory_vue_vue_type_template_id_94b5cb70___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KnowledgeBaseCategory_vue_vue_type_template_id_94b5cb70___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);